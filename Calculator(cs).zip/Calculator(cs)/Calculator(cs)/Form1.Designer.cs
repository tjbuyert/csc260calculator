﻿
namespace Calculator_cs_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BtnClearEntry = new System.Windows.Forms.Button();
            this.BtnMultiply = new System.Windows.Forms.Button();
            this.Btn9 = new System.Windows.Forms.Button();
            this.Btn8 = new System.Windows.Forms.Button();
            this.BtnSquareRoot = new System.Windows.Forms.Button();
            this.Btn7 = new System.Windows.Forms.Button();
            this.BtnMinus = new System.Windows.Forms.Button();
            this.Btn6 = new System.Windows.Forms.Button();
            this.Btn5 = new System.Windows.Forms.Button();
            this.BtnPlus = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.BtnEquals = new System.Windows.Forms.Button();
            this.BtnPeriod = new System.Windows.Forms.Button();
            this.Btn0 = new System.Windows.Forms.Button();
            this.BtnPlusMinus = new System.Windows.Forms.Button();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Btn4 = new System.Windows.Forms.Button();
            this.BtnPower = new System.Windows.Forms.Button();
            this.BtnSquare = new System.Windows.Forms.Button();
            this.BtnDivide = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.BtnClearAll = new System.Windows.Forms.Button();
            this.BtnFraction = new System.Windows.Forms.Button();
            this.txtIO = new System.Windows.Forms.TextBox();
            this.labelHistory = new System.Windows.Forms.Label();
            this.labelIO = new System.Windows.Forms.Label();
            this.txtHistory = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnClearEntry
            // 
            this.BtnClearEntry.Location = new System.Drawing.Point(68, 130);
            this.BtnClearEntry.Name = "BtnClearEntry";
            this.BtnClearEntry.Size = new System.Drawing.Size(51, 33);
            this.BtnClearEntry.TabIndex = 0;
            this.BtnClearEntry.Text = "CE";
            this.BtnClearEntry.UseVisualStyleBackColor = true;
            this.BtnClearEntry.Click += new System.EventHandler(this.BtnClearEntry_Click);
            // 
            // BtnMultiply
            // 
            this.BtnMultiply.Location = new System.Drawing.Point(239, 169);
            this.BtnMultiply.Name = "BtnMultiply";
            this.BtnMultiply.Size = new System.Drawing.Size(51, 33);
            this.BtnMultiply.TabIndex = 1;
            this.BtnMultiply.Text = "X";
            this.BtnMultiply.UseVisualStyleBackColor = true;
            this.BtnMultiply.Click += new System.EventHandler(this.BtnMultiply_Click);
            // 
            // Btn9
            // 
            this.Btn9.Location = new System.Drawing.Point(182, 169);
            this.Btn9.Name = "Btn9";
            this.Btn9.Size = new System.Drawing.Size(51, 33);
            this.Btn9.TabIndex = 2;
            this.Btn9.Text = "9";
            this.Btn9.UseVisualStyleBackColor = true;
            this.Btn9.Click += new System.EventHandler(this.Btn9_Click);
            // 
            // Btn8
            // 
            this.Btn8.Location = new System.Drawing.Point(125, 169);
            this.Btn8.Name = "Btn8";
            this.Btn8.Size = new System.Drawing.Size(51, 33);
            this.Btn8.TabIndex = 3;
            this.Btn8.Text = "8";
            this.Btn8.UseVisualStyleBackColor = true;
            this.Btn8.Click += new System.EventHandler(this.Btn8_Click);
            // 
            // BtnSquareRoot
            // 
            this.BtnSquareRoot.Location = new System.Drawing.Point(68, 91);
            this.BtnSquareRoot.Name = "BtnSquareRoot";
            this.BtnSquareRoot.Size = new System.Drawing.Size(51, 33);
            this.BtnSquareRoot.TabIndex = 4;
            this.BtnSquareRoot.Text = "Sqrt";
            this.BtnSquareRoot.UseVisualStyleBackColor = true;
            this.BtnSquareRoot.Click += new System.EventHandler(this.BtnSquareRoot_Click);
            // 
            // Btn7
            // 
            this.Btn7.Location = new System.Drawing.Point(68, 169);
            this.Btn7.Name = "Btn7";
            this.Btn7.Size = new System.Drawing.Size(51, 33);
            this.Btn7.TabIndex = 5;
            this.Btn7.Text = "7";
            this.Btn7.UseVisualStyleBackColor = true;
            this.Btn7.Click += new System.EventHandler(this.Btn7_Click);
            // 
            // BtnMinus
            // 
            this.BtnMinus.Location = new System.Drawing.Point(239, 208);
            this.BtnMinus.Name = "BtnMinus";
            this.BtnMinus.Size = new System.Drawing.Size(51, 33);
            this.BtnMinus.TabIndex = 6;
            this.BtnMinus.Text = "-";
            this.BtnMinus.UseVisualStyleBackColor = true;
            this.BtnMinus.Click += new System.EventHandler(this.BtnMinus_Click);
            // 
            // Btn6
            // 
            this.Btn6.Location = new System.Drawing.Point(182, 208);
            this.Btn6.Name = "Btn6";
            this.Btn6.Size = new System.Drawing.Size(51, 33);
            this.Btn6.TabIndex = 7;
            this.Btn6.Text = "6";
            this.Btn6.UseVisualStyleBackColor = true;
            this.Btn6.Click += new System.EventHandler(this.Btn6_Click);
            // 
            // Btn5
            // 
            this.Btn5.Location = new System.Drawing.Point(125, 208);
            this.Btn5.Name = "Btn5";
            this.Btn5.Size = new System.Drawing.Size(51, 33);
            this.Btn5.TabIndex = 8;
            this.Btn5.Text = "5";
            this.Btn5.UseVisualStyleBackColor = true;
            this.Btn5.Click += new System.EventHandler(this.Btn5_Click);
            // 
            // BtnPlus
            // 
            this.BtnPlus.Location = new System.Drawing.Point(239, 247);
            this.BtnPlus.Name = "BtnPlus";
            this.BtnPlus.Size = new System.Drawing.Size(51, 33);
            this.BtnPlus.TabIndex = 9;
            this.BtnPlus.Text = "+";
            this.BtnPlus.UseVisualStyleBackColor = true;
            this.BtnPlus.Click += new System.EventHandler(this.BtnPlus_Click);
            // 
            // Btn3
            // 
            this.Btn3.Location = new System.Drawing.Point(182, 247);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(51, 33);
            this.Btn3.TabIndex = 10;
            this.Btn3.Text = "3";
            this.Btn3.UseVisualStyleBackColor = true;
            this.Btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // Btn2
            // 
            this.Btn2.Location = new System.Drawing.Point(125, 247);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(51, 33);
            this.Btn2.TabIndex = 11;
            this.Btn2.Text = "2";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // BtnEquals
            // 
            this.BtnEquals.Location = new System.Drawing.Point(239, 286);
            this.BtnEquals.Name = "BtnEquals";
            this.BtnEquals.Size = new System.Drawing.Size(51, 33);
            this.BtnEquals.TabIndex = 12;
            this.BtnEquals.Text = "=";
            this.BtnEquals.UseVisualStyleBackColor = true;
            this.BtnEquals.Click += new System.EventHandler(this.BtnEquals_Click);
            // 
            // BtnPeriod
            // 
            this.BtnPeriod.Location = new System.Drawing.Point(182, 286);
            this.BtnPeriod.Name = "BtnPeriod";
            this.BtnPeriod.Size = new System.Drawing.Size(51, 33);
            this.BtnPeriod.TabIndex = 13;
            this.BtnPeriod.Text = ".";
            this.BtnPeriod.UseVisualStyleBackColor = true;
            this.BtnPeriod.Click += new System.EventHandler(this.BtnPeriod_Click);
            // 
            // Btn0
            // 
            this.Btn0.Location = new System.Drawing.Point(125, 286);
            this.Btn0.Name = "Btn0";
            this.Btn0.Size = new System.Drawing.Size(51, 33);
            this.Btn0.TabIndex = 14;
            this.Btn0.Text = "0";
            this.Btn0.UseVisualStyleBackColor = true;
            this.Btn0.Click += new System.EventHandler(this.Btn0_Click);
            // 
            // BtnPlusMinus
            // 
            this.BtnPlusMinus.Location = new System.Drawing.Point(68, 286);
            this.BtnPlusMinus.Name = "BtnPlusMinus";
            this.BtnPlusMinus.Size = new System.Drawing.Size(51, 33);
            this.BtnPlusMinus.TabIndex = 15;
            this.BtnPlusMinus.Text = "+/-";
            this.BtnPlusMinus.UseVisualStyleBackColor = true;
            this.BtnPlusMinus.Click += new System.EventHandler(this.BtnPlusMinus_Click);
            // 
            // Btn1
            // 
            this.Btn1.Location = new System.Drawing.Point(68, 247);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(51, 33);
            this.Btn1.TabIndex = 16;
            this.Btn1.Text = "1";
            this.Btn1.UseVisualStyleBackColor = true;
            this.Btn1.Click += new System.EventHandler(this.button17_Click);
            // 
            // Btn4
            // 
            this.Btn4.Location = new System.Drawing.Point(68, 208);
            this.Btn4.Name = "Btn4";
            this.Btn4.Size = new System.Drawing.Size(51, 33);
            this.Btn4.TabIndex = 17;
            this.Btn4.Text = "4";
            this.Btn4.UseVisualStyleBackColor = true;
            this.Btn4.Click += new System.EventHandler(this.Btn4_Click);
            // 
            // BtnPower
            // 
            this.BtnPower.Location = new System.Drawing.Point(182, 91);
            this.BtnPower.Name = "BtnPower";
            this.BtnPower.Size = new System.Drawing.Size(51, 33);
            this.BtnPower.TabIndex = 18;
            this.BtnPower.Text = "x^y";
            this.BtnPower.UseVisualStyleBackColor = true;
            this.BtnPower.Click += new System.EventHandler(this.BtnPower_Click);
            // 
            // BtnSquare
            // 
            this.BtnSquare.Location = new System.Drawing.Point(125, 91);
            this.BtnSquare.Name = "BtnSquare";
            this.BtnSquare.Size = new System.Drawing.Size(51, 33);
            this.BtnSquare.TabIndex = 19;
            this.BtnSquare.Text = "x^2";
            this.BtnSquare.UseVisualStyleBackColor = true;
            this.BtnSquare.Click += new System.EventHandler(this.BtnSquare_Click);
            // 
            // BtnDivide
            // 
            this.BtnDivide.Location = new System.Drawing.Point(239, 130);
            this.BtnDivide.Name = "BtnDivide";
            this.BtnDivide.Size = new System.Drawing.Size(51, 33);
            this.BtnDivide.TabIndex = 20;
            this.BtnDivide.Text = "/";
            this.BtnDivide.UseVisualStyleBackColor = true;
            this.BtnDivide.Click += new System.EventHandler(this.BtnDivide_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(182, 130);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(51, 33);
            this.BtnDelete.TabIndex = 21;
            this.BtnDelete.Text = "Del";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnClearAll
            // 
            this.BtnClearAll.Location = new System.Drawing.Point(125, 130);
            this.BtnClearAll.Name = "BtnClearAll";
            this.BtnClearAll.Size = new System.Drawing.Size(51, 33);
            this.BtnClearAll.TabIndex = 22;
            this.BtnClearAll.Text = "C";
            this.BtnClearAll.UseVisualStyleBackColor = true;
            this.BtnClearAll.Click += new System.EventHandler(this.BtnClearAll_Click);
            // 
            // BtnFraction
            // 
            this.BtnFraction.Location = new System.Drawing.Point(239, 91);
            this.BtnFraction.Name = "BtnFraction";
            this.BtnFraction.Size = new System.Drawing.Size(51, 33);
            this.BtnFraction.TabIndex = 23;
            this.BtnFraction.Text = "1/x";
            this.BtnFraction.UseVisualStyleBackColor = true;
            this.BtnFraction.Click += new System.EventHandler(this.BtnFraction_Click);
            // 
            // txtIO
            // 
            this.txtIO.Location = new System.Drawing.Point(68, 62);
            this.txtIO.Name = "txtIO";
            this.txtIO.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtIO.Size = new System.Drawing.Size(222, 23);
            this.txtIO.TabIndex = 24;
            this.txtIO.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtIO.TextChanged += new System.EventHandler(this.txtIO_TextChanged);
            // 
            // labelHistory
            // 
            this.labelHistory.AutoSize = true;
            this.labelHistory.Location = new System.Drawing.Point(424, 71);
            this.labelHistory.Name = "labelHistory";
            this.labelHistory.Size = new System.Drawing.Size(45, 15);
            this.labelHistory.TabIndex = 25;
            this.labelHistory.Text = "History";
            this.labelHistory.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelIO
            // 
            this.labelIO.AutoSize = true;
            this.labelIO.Location = new System.Drawing.Point(68, 41);
            this.labelIO.Name = "labelIO";
            this.labelIO.Size = new System.Drawing.Size(78, 15);
            this.labelIO.TabIndex = 26;
            this.labelIO.Text = "Input/Output";
            this.labelIO.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtHistory
            // 
            this.txtHistory.Location = new System.Drawing.Point(424, 91);
            this.txtHistory.Multiline = true;
            this.txtHistory.Name = "txtHistory";
            this.txtHistory.Size = new System.Drawing.Size(233, 228);
            this.txtHistory.TabIndex = 27;
            this.txtHistory.TextChanged += new System.EventHandler(this.txtHistory_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(731, 374);
            this.Controls.Add(this.txtHistory);
            this.Controls.Add(this.labelIO);
            this.Controls.Add(this.labelHistory);
            this.Controls.Add(this.txtIO);
            this.Controls.Add(this.BtnFraction);
            this.Controls.Add(this.BtnClearAll);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.BtnDivide);
            this.Controls.Add(this.BtnSquare);
            this.Controls.Add(this.BtnPower);
            this.Controls.Add(this.Btn4);
            this.Controls.Add(this.Btn1);
            this.Controls.Add(this.BtnPlusMinus);
            this.Controls.Add(this.Btn0);
            this.Controls.Add(this.BtnPeriod);
            this.Controls.Add(this.BtnEquals);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.BtnPlus);
            this.Controls.Add(this.Btn5);
            this.Controls.Add(this.Btn6);
            this.Controls.Add(this.BtnMinus);
            this.Controls.Add(this.Btn7);
            this.Controls.Add(this.BtnSquareRoot);
            this.Controls.Add(this.Btn8);
            this.Controls.Add(this.Btn9);
            this.Controls.Add(this.BtnMultiply);
            this.Controls.Add(this.BtnClearEntry);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnClearEntry;
        private System.Windows.Forms.Button BtnMultiply;
        private System.Windows.Forms.Button Btn9;
        private System.Windows.Forms.Button Btn8;
        private System.Windows.Forms.Button BtnSquareRoot;
        private System.Windows.Forms.Button Btn7;
        private System.Windows.Forms.Button BtnMinus;
        private System.Windows.Forms.Button Btn6;
        private System.Windows.Forms.Button Btn5;
        private System.Windows.Forms.Button BtnPlus;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button BtnEquals;
        private System.Windows.Forms.Button BtnPeriod;
        private System.Windows.Forms.Button Btn0;
        private System.Windows.Forms.Button BtnPlusMinus;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Button Btn4;
        private System.Windows.Forms.Button BtnPower;
        private System.Windows.Forms.Button BtnSquare;
        private System.Windows.Forms.Button BtnDivide;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.Button BtnClearAll;
        private System.Windows.Forms.Button BtnFraction;
        private System.Windows.Forms.TextBox txtIO;
        private System.Windows.Forms.Label labelHistory;
        private System.Windows.Forms.Label labelIO;
        private System.Windows.Forms.TextBox txtHistory;
    }
}


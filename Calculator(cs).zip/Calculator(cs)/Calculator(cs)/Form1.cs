﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_cs_
{
    public partial class Form1 : Form
    {
        string tempInput = "";
        string userInput1 = "";
        string userInput2 = "";
        char operation;
 
        
        public Form1()
        {
            InitializeComponent();
            txtIO.Text = "";
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            KeyPreview = true;
            KeyPress += Form1_KeyPress;
        }

        void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch((int)e.KeyChar)
            {
                case 8: //backspace (del)
                    BtnDelete_Click(BtnDelete, new EventArgs());
                    break;
                case 42: //multiplying
                    BtnMultiply_Click(BtnMultiply, new EventArgs());
                    break;
                case 43: //adding
                    BtnPlus_Click(BtnPlus, new EventArgs());
                    break;
                case 45: //subtracting
                    BtnMinus_Click(BtnMinus, new EventArgs());
                    break;
                case 46: //period
                    BtnPeriod_Click(BtnPeriod, new EventArgs());
                    break;
                case 47: //dividing
                    BtnDivide_Click(BtnDivide, new EventArgs());
                    break;
                case 48: //0
                    Btn0_Click(Btn0, new EventArgs());
                    break;
                case 49: //1
                    button17_Click(Btn1, new EventArgs());
                    break;
                case 50: //2
                    Btn2_Click(Btn2, new EventArgs());
                    break;
                case 51: //3
                    Btn3_Click(Btn3, new EventArgs());
                    break;
                case 52: //4
                    Btn4_Click(Btn4, new EventArgs());
                    break;
                case 53: //5
                    Btn5_Click(Btn5, new EventArgs());
                    break;
                case 54: //6
                    Btn6_Click(Btn6, new EventArgs());
                    break;
                case 55: //7
                    Btn7_Click(Btn7, new EventArgs());
                    break;
                case 56: //8
                    Btn8_Click(Btn8, new EventArgs());
                    break;
                case 57: //9
                    Btn9_Click(Btn9, new EventArgs());
                    break;
                case 61: //equals
                    BtnEquals_Click(BtnEquals, new EventArgs());
                    break;
            }
        }

        //number buttons

        private void Btn0_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "0";
                tempInput += "0";
            }
            else
            {
                txtIO.Text += "0";
                tempInput += "0";
            }
        }

        private void button17_Click(object sender, EventArgs e) //button 1

        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "1";
                tempInput += "1";
            }
            else
            {
                txtIO.Text += "1";
                tempInput += "1";
            }
        }
        private void Btn2_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "2";
                tempInput += "2";
            }
            else
            {
                txtIO.Text += "2";
                tempInput += "2";
            }
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "3";
                tempInput += "3";
            }
            else
            {
                txtIO.Text += "3";
                tempInput += "3";
            }
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "4";
                tempInput += "4";
            }
            else
            {
                txtIO.Text += "4";
                tempInput += "4";
            }
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "5";
                tempInput += "5";
            }
            else
            {
                txtIO.Text += "5";
                tempInput += "5";
            }
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "6";
                tempInput += "6";
            }
            else
            {
                txtIO.Text += "6";
                tempInput += "6";
            }
        }
        private void Btn7_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "7";
                tempInput += "7";
            }
            else
            {
                txtIO.Text += "7";
                tempInput += "7";
            }
        }
        private void Btn8_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "8";
                tempInput += "8";
            }
            else
            {
                txtIO.Text += "8";
                tempInput += "8";
            }
        }

        private void Btn9_Click(object sender, EventArgs e)
        {
            if (txtIO.Text == "0")
            {
                txtIO.Text = "9";
                tempInput += "9";
            }
            else
            {
                txtIO.Text += "9";
                tempInput += "9";
            }
        }

        //Math buttons

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            if (tempInput != "")
            {
                userInput1 = tempInput;
                txtHistory.Text += tempInput;
            }

            tempInput = "";

            if (!txtIO.Text.Contains("+"))
            {
                txtIO.Text += "+";
                txtHistory.Text += "+";
            }

            operation = '+';
            
        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            if (tempInput != "")
            {
                userInput1 = tempInput;
                txtHistory.Text += tempInput;
            }

            tempInput = "";

            if (!txtIO.Text.Contains("-"))
            {
                txtIO.Text += "-";
                txtHistory.Text += "-";
            }

            operation = '-';
            
        }

        private void BtnMultiply_Click(object sender, EventArgs e)
        {
            if (tempInput != "")
            {
                userInput1 = tempInput;
                txtHistory.Text += tempInput;
            }

            tempInput = "";

            if (!txtIO.Text.Contains("*"))
            {
                txtIO.Text += "*";
                txtHistory.Text += "*";
            }

            operation = '*';
            
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            if (tempInput != "")
            {
                userInput1 = tempInput;
                txtHistory.Text += tempInput;
            }

            tempInput = "";

            if (!txtIO.Text.Contains("/"))
            {
                txtIO.Text += "/";
                txtHistory.Text += "/";
            }

            operation = '/';
            

        }

        private void BtnEquals_Click(object sender, EventArgs e) //EQUALSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
        {
            if(tempInput != "")
            {
                double tempDouble = 0;
                double tempDouble2 = 0;

                txtHistory.Text += tempInput + " = ";


                if (operation == '+')
                {
                    tempDouble = Convert.ToDouble(userInput1);
                    tempDouble2 = Convert.ToDouble(tempInput);
                    tempDouble = tempDouble + tempDouble2;
                    tempInput = Convert.ToString(tempDouble);
                    txtIO.Text = tempInput;
                    txtHistory.Text += tempInput;
                }

                if (operation == '-')
                {
                    tempDouble = Convert.ToDouble(userInput1);
                    tempDouble2 = Convert.ToDouble(tempInput);
                    tempDouble = tempDouble - tempDouble2;
                    tempInput = Convert.ToString(tempDouble);
                    txtIO.Text = tempInput;
                    txtHistory.Text += tempInput;
                }

                if (operation == '*')
                {
                    tempDouble = Convert.ToDouble(userInput1);
                    tempDouble2 = Convert.ToDouble(tempInput);
                    tempDouble = tempDouble * tempDouble2;
                    tempInput = Convert.ToString(tempDouble);
                    txtIO.Text = tempInput;
                    txtHistory.Text += tempInput;
                }

                if (operation == '/')
                {

                    tempDouble = Convert.ToDouble(userInput1);
                    tempDouble2 = Convert.ToDouble(tempInput);
                    if (tempDouble2 == 0)
                    {
                        txtIO.Text = "Undefined";
                        tempInput = "";
                        txtHistory.Text += "Undefined";
                    }
                    else
                    {
                        tempDouble = tempDouble / tempDouble2;
                        tempInput = Convert.ToString(tempDouble);
                        txtIO.Text = tempInput;
                        txtHistory.Text += tempInput;
                    }

                }

                if (operation == 'P') // X to the power of Y
                {
                    if (tempInput != "")
                    {
                        userInput2 = tempInput;
                        tempDouble = Convert.ToDouble(userInput1);
                        tempDouble2 = Convert.ToDouble(userInput2);
                        tempDouble = Math.Pow(tempDouble, tempDouble2);
                        tempInput = Convert.ToString(tempDouble);
                        txtIO.Text = tempInput;
                        txtHistory.Text += tempInput;
                    }
                }

                txtHistory.Text += "\n";
            }
            
        }



        //clearing
        private void BtnClearEntry_Click(object sender, EventArgs e) //Clears the entry, but not the operation or history.
        {
            tempInput = "";
            txtIO.Text = "0";
        }

        private void BtnClearAll_Click(object sender, EventArgs e) //Clears the entry, operation, and history.
        {
            txtIO.Text = "0";
            tempInput = "";
            txtHistory.Text = "";
            userInput1 = "";
            userInput2 = "";
        }

        private void BtnDelete_Click(object sender, EventArgs e) //Deletes one character from tempInput. If there is one character left in temp input, it replaces it with a 0.
        {
            while (tempInput.Length != 0)
            {
                if (tempInput.Length == 1)
                {
                    tempInput = "";
                    txtIO.Text = "0";
                }
                else
                {
                    tempInput = tempInput.Remove(tempInput.Length - 1, 1);
                    txtIO.Text = tempInput;
                }
            }
        }

        //operations

        private void BtnPeriod_Click(object sender, EventArgs e) //Places a period in the tempInput string as long as there is not one in the string.
        {
            if (!tempInput.Contains('.'))
            {
                tempInput += ".";
                txtIO.Text += ".";
            }
        }

        private void BtnSquareRoot_Click(object sender, EventArgs e) //Finds and returns the square root of tempInput.
        {
            if (tempInput != "")
            {
                txtHistory.Text += "Sqrt " + tempInput + " = ";
                double tempVar = 0;
                tempVar = Convert.ToDouble(tempInput);
                tempVar = Math.Sqrt(tempVar);
                tempInput = Convert.ToString(tempVar);
                txtIO.Text = tempInput;
                txtHistory.Text += tempInput + " \n";
            }
        }



        private void BtnPlusMinus_Click(object sender, EventArgs e) //Converts tempInput to a negative number, or to a positive number if tempInput is negative.
        {
            txtHistory.Text += tempInput + " (+/-) = ";
            double tempVar = 0;
            tempVar = Convert.ToDouble(tempInput);
            tempVar = tempVar * -1;
            tempInput = Convert.ToString(tempVar);
            txtIO.Text = tempInput;
            txtHistory.Text += tempInput + " \n";
        }

        private void BtnSquare_Click(object sender, EventArgs e) //Squares the current value of tempInput. Does not require an Equals input.
        {
            if (tempInput != "")
            {
                txtHistory.Text += tempInput + "^2 = ";
                double tempVar = 0;
                tempVar = Convert.ToDouble(tempInput);
                tempVar = Math.Pow(tempVar, 2);
                tempInput = Convert.ToString(tempVar);
                txtIO.Text = tempInput;
                txtHistory.Text += tempInput + '\n';
            }
        }

        private void BtnPower_Click(object sender, EventArgs e) //Raises the first input to the power of the second input. ex: (X ^ Y)
        {
            if (tempInput != "")
            {
                operation = 'P';
                userInput1 = tempInput;
                txtIO.Text += "^";
                txtHistory.Text += tempInput + "^";
                tempInput = "";
            }
        }

        private void BtnFraction_Click(object sender, EventArgs e) //Divides the first input by the second input and returns the decimal value as a double.
        {
            if (tempInput != "")
            {
                double tempDouble = 0;
                tempDouble = Convert.ToDouble(tempInput);
                tempDouble = 1 / tempDouble;
                tempInput = Convert.ToString(tempDouble);
                txtIO.Text = tempInput;
                txtHistory.Text += "1/x = " + tempInput;
            }
        }

        //display functions

        private void txtHistory_TextChanged(object sender, EventArgs e)
        {
            //not used
        }

        private void txtIO_TextChanged(object sender, EventArgs e)
        {
            //not used
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //not used
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //not used
        }

    }
}
